
//
//  FJFFourViewController.m
//  FJFTouchEventDemo
//
//  Created by 方金峰 on 2019/2/13.
//  Copyright © 2019年 方金峰. All rights reserved.
//

#import "FJFFourViewController.h"

@interface FJFFourViewController ()

@end

@implementation FJFFourViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
     self.title = @"我的";
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
