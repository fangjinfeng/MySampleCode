

//
//  FJFWindow.m
//  FJFTouchEventDemo
//
//  Created by 方金峰 on 2019/2/14.
//  Copyright © 2019年 方金峰. All rights reserved.
//

#import "FJFWindow.h"

@implementation FJFWindow

#pragma mark -------------------------- Override Methods
- (void)sendEvent:(UIEvent *)event {
    [super sendEvent:event];
}

@end
